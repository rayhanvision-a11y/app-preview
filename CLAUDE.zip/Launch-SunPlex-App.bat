@echo off
title Launching SunPlex IPTV App...

:: Set current directory
cd /d "%~dp0"

:: Target URL: check if localhost server is accessible, else use local HTML file
set "APP_URL=http://localhost/SunPlex%%20App/index.html"
set "LOCAL_FILE=file:///%~dp0index.html"

:: Check if localhost is responding (curl timeout 1s)
curl -s --head --request GET "http://localhost" --max-time 1 >nul 2>&1
if %errorlevel% equ 0 (
    set "TARGET_URL=%APP_URL%"
) else (
    set "TARGET_URL=%LOCAL_FILE%"
)

:: Locate Microsoft Edge or Google Chrome
set "BROWSER_EXE="

if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=C:\Program Files\Google\Chrome\Application\chrome.exe"
) else if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
) else if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%LocalAppData%\Google\Chrome\Application\chrome.exe"
) else if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
    set "BROWSER_EXE=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
) else if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" (
    set "BROWSER_EXE=C:\Program Files\Microsoft\Edge\Application\msedge.exe"
)

:: Launch in borderless standalone App Mode
if defined BROWSER_EXE (
    start "" "%BROWSER_EXE%" --app="%TARGET_URL%" --window-size=1366,768
) else (
    :: Fallback to default browser
    start "" "%TARGET_URL%"
)

exit
