' SunPlex IPTV Silent App Launcher
Set WshShell = CreateObject("WScript.Shell")
strPath = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
WshShell.Run Chr(34) & strPath & "\Launch-SunPlex-App.bat" & Chr(34), 0, False
Set WshShell = Nothing
