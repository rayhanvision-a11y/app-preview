@echo off
title Creating SunPlex Desktop App Shortcut...

set "SCRIPT_DIR=%~dp0"
set "VBS_FILE=%TEMP%\CreateSunPlexShortcut.vbs"

echo Set oWS = WScript.CreateObject("WScript.Shell") > "%VBS_FILE%"
echo sLinkFile = oWS.SpecialFolders("Desktop") ^& "\SunPlex IPTV.lnk" >> "%VBS_FILE%"
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> "%VBS_FILE%"
echo oLink.TargetPath = "%SCRIPT_DIR%Launch-SunPlex-App.vbs" >> "%VBS_FILE%"
echo oLink.WorkingDirectory = "%SCRIPT_DIR%" >> "%VBS_FILE%"
echo oLink.Description = "SunPlex IPTV Streaming Media App" >> "%VBS_FILE%"
echo oLink.Save >> "%VBS_FILE%"

cscript //nologo "%VBS_FILE%"
del "%VBS_FILE%"

echo Shortcut "SunPlex IPTV" has been created on your Desktop!
echo You can now double click it to open SunPlex directly in App Mode.
pause
